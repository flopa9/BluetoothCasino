# Bluetooth Casino — prototype 0.1

This is the initial Android project skeleton.

## Included
- Dark casino lobby UI
- Three game entry screens: Blackjack 21, Roulette, Airplane
- Virtual demo balance
- Bluetooth room screen placeholder
- GitHub Actions workflow to build a debug APK

## Not implemented yet
Bluetooth pairing/networking, multiplayer synchronization, game rules, dealer bot, and persistent profiles are future development steps.

## Build APK in GitHub Actions
1. Create a new empty GitHub repository.
2. Upload the contents of this folder to the repository (keep folder structure).
3. Open Actions and run **Build Android APK** (or push to `main`).
4. Download the `Bluetooth-Casino-debug` artifact from the completed workflow run.
5. Extract it and install `app-debug.apk` on Android.

The app uses virtual points only; no real-money wagering.
