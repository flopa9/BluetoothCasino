package com.example.bluetoothcasino

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF101014)
private val Panel = Color(0xFF1D1D25)
private val Gold = Color(0xFFE2B85B)
private val Cream = Color(0xFFF6EBD0)
private val Muted = Color(0xFFAAA6A0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CasinoApp() }
    }
}

@Composable
fun CasinoApp() {
    var selected by remember { mutableStateOf("Лобби") }
    var balance by remember { mutableIntStateOf(10000) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Night,
            surface = Panel,
            primary = Gold,
            onPrimary = Night,
            onBackground = Cream,
            onSurface = Cream
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Night) {
            when (selected) {
                "Блэкджек" -> GamePlaceholder("БЛЭКДЖЕК 21", "Бот-крупье будет раздавать карты.", balance) { selected = "Лобби" }
                "Рулетка" -> GamePlaceholder("РУЛЕТКА", "Ставки на виртуальные фишки.", balance) { selected = "Лобби" }
                "Самолётик" -> GamePlaceholder("САМОЛЁТИК", "Crash-режим с виртуальными очками.", balance) { selected = "Лобби" }
                else -> Lobby(balance, onGame = { selected = it }, onBluetooth = { selected = "Bluetooth" })
            }
            if (selected == "Bluetooth") {
                BluetoothScreen(onBack = { selected = "Лобби" })
            }
        }
    }
}

@Composable
fun Lobby(balance: Int, onGame: (String) -> Unit, onBluetooth: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF242018), Night, Night))
        ).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("BLUETOOTH", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Text("CASINO", color = Cream, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("ТВОЙ БАЛАНС", color = Muted, fontSize = 10.sp)
                Text("🪙 ${"%,d".format(balance)}", color = Gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF332817)),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("ВАШ ИГРОВОЙ ЗАЛ", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Играй вдвоём.
Крупье — бот.", color = Cream, fontSize = 25.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp)
                Text("Локальная игра по Bluetooth • Без интернета", color = Muted, fontSize = 12.sp)
                Button(onClick = onBluetooth, colors = ButtonDefaults.buttonColors(containerColor = Gold), modifier = Modifier.padding(top = 8.dp)) {
                    Icon(Icons.Default.Bluetooth, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("ИГРАТЬ С ДРУГОМ", fontWeight = FontWeight.Bold)
                }
            }
        }

        Text("ИГРОВЫЕ СТОЛЫ", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        GameTile("♠", "БЛЭКДЖЕК 21", "Игрок против игрока и бота-крупье", "Блэкджек", onGame)
        GameTile("◉", "РУЛЕТКА", "Классическое колесо и ставки", "Рулетка", onGame)
        GameTile("✈", "САМОЛЁТИК", "Успей забрать виртуальный выигрыш", "Самолётик", onGame)

        Spacer(Modifier.weight(1f))
        Text("ПРОФИЛЬ  •  ГОСТЬ          ВЕРСИЯ 0.1", color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun GameTile(symbol: String, title: String, subtitle: String, game: String, onGame: (String) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onGame(game) },
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).background(Color(0xFF332817), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Text(symbol, color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, color = Cream, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(subtitle, color = Muted, fontSize = 11.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Gold)
        }
    }
}

@Composable
fun GamePlaceholder(title: String, description: String, balance: Int, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Night).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(title, color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(18.dp))
        Text(description, color = Cream, fontSize = 16.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text("Баланс: 🪙 $balance", color = Muted)
        Spacer(Modifier.height(28.dp))
        Text("ИГРОВОЙ СТОЛ ПОЯВИТСЯ В СЛЕДУЮЩЕЙ ВЕРСИИ", color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(28.dp))
        Button(onClick = onBack, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("НАЗАД В ЛОББИ") }
    }
}

@Composable
fun BluetoothScreen(onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Night).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Bluetooth, contentDescription = null, tint = Gold, modifier = Modifier.size(64.dp))
        Spacer(Modifier.height(18.dp))
        Text("ИГРА С ДРУГОМ", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(10.dp))
        Text("Подключение Bluetooth добавим следующим этапом. Сейчас это экран-заготовка.", color = Cream, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onBack, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("НАЗАД") }
    }
}
